<?php 
$db = mysql_connect("localhost","root","");
mysql_select_db("comments",$db);
mysql_query("SET NAMES utf8");
?>